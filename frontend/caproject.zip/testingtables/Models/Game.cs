﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace testingtables.Models
{
    public class Game
    {
        public int productId { get; set; }
        public string productName { get; set; }
        public string productDes { get; set; }
        public decimal unitPrice { get; set; }
        public string imgUrl{ get; set; }
        public bool isOnSale { get; set; }
        public float discountPercent { get; set; }
    }
}
