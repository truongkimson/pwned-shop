﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;


namespace testingtables.Models
{
    public class GameRepository : IGameRepository
    {
        public IEnumerable<Game> getAllGame => new List<Game>
        {
            new Game {productId = 1,
                productName = "Outriders",
                productDes = "Outriders’ brutal and bloody combat combines frenetic gunplay, violent powers and deep RPG systems to create a true genre hybrid.",
                unitPrice = 82.50M,
                imgUrl = "https://cdn.cloudflare.steamstatic.com/steam/apps/680420/header.jpg?t=1617900801",
                discountPercent = 0F,
                isOnSale = false},

            new Game {productId = 2,
                productName = "No Man’s Sky",
                productDes = "No Man’s Sky is a game about exploration and survival in an inifinite procedurally generated universe.",
                unitPrice = 59.90M,
                imgUrl = "https://cdn.cloudflare.steamstatic.com/steam/apps/275850/header_alt_assets_2.jpg?t=1617200814",
                discountPercent = 0F,
                isOnSale = false},

            new Game{productId = 3,
                productName = "Horizon Zero Dawn",
                productDes = "Experience Aloy’s legendary quest to unravel the mysteries of a future Earth ruled by Machines! Use devastating tactical attacks against your prey and explore a majestic open world.",
                unitPrice = 55.00M,
                imgUrl = "https://cdn.cloudflare.steamstatic.com/steam/apps/1151640/header.jpg?t=1617204098",
                discountPercent = 0.1F,
                isOnSale = true},

            new Game{productId = 4,
                productName = "Wasteland 3  ",
                productDes = "Following the critically acclaimed 2014 Game of the Year winner Wasteland 2, the RPG series that pioneered the post-apocalyptic genre in video games returns with Wasteland 3.",
                unitPrice = 49.00M,
                imgUrl = "https://cdn.cloudflare.steamstatic.com/steam/apps/719040/header.jpg?t=1608241131",
                discountPercent = 0.1F,
                isOnSale = true},

            new Game{productId = 5,
                productName = "Control Ultimate Edition",
                productDes = "Winner of over 80 awards, Control is a visually stunning third-person action-adventure that will keep you on the edge of your seat.",
                unitPrice = 40.00M,
                imgUrl = "https://cdn.cloudflare.steamstatic.com/steam/apps/870780/header.jpg?t=1614637768",
                discountPercent = 0.1F,
                isOnSale = true},

            new Game{productId = 6,
                productName = "Evil Genius 2",
                productDes = "A satirical spy-fi lair builder where YOU are the criminal mastermind! Construct your base, train your minions, defend your operations from the Forces of Justice, and achieve global domination!",
                unitPrice = 34.00M,
                imgUrl = "https://cdn.cloudflare.steamstatic.com/steam/apps/700600/header.jpg?t=1617192467",
                discountPercent = 0.1F,
                isOnSale = true},

            new Game{productId = 7,
                productName = "Jurassic World Evolution  ",
                productDes = "Take charge of operations on the legendary islands of the Muertes archipelago and bring the wonder, majesty and danger of dinosaurs to life.",
                unitPrice = 58.00M,
                imgUrl = "https://cdn.cloudflare.steamstatic.com/steam/apps/648350/header.jpg?t=1595319162",
                discountPercent = 0F,
                isOnSale = false},

            new Game{productId = 8,
                productName = "Element TD 2",
                productDes = "Prove your defenses against challenging foes, and compete or cooperate with others to determine who has mastered the elements.",
                unitPrice = 18.00M,
                imgUrl = "https://cdn.cloudflare.steamstatic.com/steam/apps/1018830/header.jpg?t=1617701981",
                discountPercent = 0F,
                isOnSale = false},

            new Game {productId = 9,
                productName = "Valheim",
                productDes = "A brutal exploration and survival game set in a procedurally-generated purgatory inspired by viking culture. Battle, build, and conquer your way to a saga worthy of Odin’s patronage!",
                unitPrice = 18.50M,
                imgUrl = "https://cdn.cloudflare.steamstatic.com/steam/apps/892970/header.jpg?t=1617258628",
                discountPercent = 0F,
                isOnSale = false},

            new Game {productId = 10,
                productName = "Planet Zoo",
                productDes = "Build a world for wildlife in Planet Zoo. From the developers of Planet Coaster and Zoo Tycoon comes the ultimate zoo sim.",
                unitPrice = 42.49M,
                imgUrl = "https://cdn.cloudflare.steamstatic.com/steam/apps/703080/header_alt_assets_1.jpg?t=1617099203",
                discountPercent = 0.1F,
                isOnSale = true},

            new Game{productId = 11,
                productName = "Yakuza 6",
                productDes = "Step into Japan's criminal underworld in this explosive action brawler starring legendary yakuza, Kazuma Kiryu, who is hellbent on unraveling the truth around his daughter's tragic accident.",
                unitPrice = 24.90M,
                imgUrl = "https://cdn.cloudflare.steamstatic.com/steam/apps/1388590/header.jpg?t=1616691256",
                discountPercent = 0F,
                isOnSale = false},

            new Game{productId = 12,
                productName = "Nanotale",
                productDes = "Something is wrong with the heart of magic. Play a young archivist venturing out into a dying world, cataloging its mysteries and its wonders to unearth the truth.",
                unitPrice = 18.50M,
                imgUrl = "https://cdn.cloudflare.steamstatic.com/steam/apps/944920/header.jpg?t=1617372156",
                discountPercent = 0F,
                isOnSale = false},

            new Game{productId = 13,
                productName = "Enderal",
                productDes = "Enderal offers an immersive open world, new skill systems and gameplay with a dark, psychological storyline and believable characters.",
                unitPrice = 59.90M,
                imgUrl = "https://cdn.cloudflare.steamstatic.com/steam/apps/976620/header.jpg?t=1617715250",
                discountPercent = 0F,
                isOnSale = false},

            new Game{productId = 14,
                productName = "It Takes Two",
                productDes = "Embark on the craziest journey of your life in It Takes Two. Invite a friend to join for free with Friend’s Pass and work together in this gameplay challenges.",
                unitPrice = 54.90M,
                imgUrl = "https://cdn.cloudflare.steamstatic.com/steam/apps/1426210/header_alt_assets_0.jpg?t=1617275485",
                discountPercent = 0.1F,
                isOnSale = true},

            new Game{productId = 15,
                productName = "Forza Horizon 4",
                productDes = "Dynamic seasons change everything at the world’s greatest automotive festival. Go it alone or team up with others to explore beautiful and historic Britain in a shared open world.",
                unitPrice = 79.90M,
                imgUrl = "https://cdn.cloudflare.steamstatic.com/steam/apps/1293830/header.jpg?t=1615337540",
                discountPercent = 0.1F,
                isOnSale = true},

            new Game{productId = 16,
                productName = "Persona 5 Strikers",
                productDes = "Join the Phantom Thieves and strike back against the corruption overtaking cities across Japan. A summer vacation with close friends takes a sudden turn as a distorted reality emerges.",
                unitPrice = 72.90M,
                imgUrl = "https://cdn.cloudflare.steamstatic.com/steam/apps/1382330/header.jpg?t=1614057973",
                discountPercent = 0.1F,
                isOnSale = true},

            new Game{productId = 17,
                productName = "Nioh 2",
                productDes = "Create your protagonist and embark on an adventure through a myriad of locales across Japan during the Sengoku period.",
                unitPrice = 67.90M,
                imgUrl = "https://cdn.cloudflare.steamstatic.com/steam/apps/1325200/header.jpg?t=1614948556",
                discountPercent = 0F,
                isOnSale = false},

            new Game{productId = 18,
                productName = "Sen no Kiseki III",
                productDes = "The Legend of Heroes: Sen no Kiseki role-playing game series is highly acclaimed by gamers all over the world for its elaborate character portrayals and epic storyline.",
                unitPrice = 99.90M,
                imgUrl = "https://cdn.cloudflare.steamstatic.com/steam/apps/1555263/header.jpg?t=1616598378",
                discountPercent = 0F,
                isOnSale = false},

            new Game{productId = 19,
                productName = "Wild Terra 2: New Lands",
                productDes = "MMORPG full of logically interconnected worked out little things that create a unique immersion and the spirit of adventure!",
                unitPrice = 29.00M,
                imgUrl = "https://cdn.cloudflare.steamstatic.com/steam/apps/1134700/header.jpg?t=1617691297",
                discountPercent = 0F,
                isOnSale = false},

            new Game{productId = 20,
                productName = "Cartel Tycoon",
                productDes = "Cartel Tycoon is a survival business sim inspired by the ‘80s narco trade. Expand and conquer, fight off rival cartels and evade the authorities.",
                unitPrice = 22.90M,
                imgUrl = "https://cdn.cloudflare.steamstatic.com/steam/apps/1220140/header.jpg?t=1616941947",
                discountPercent = 0F,
                isOnSale = false}
        };

        IEnumerator<Game> IGameRepository.getGameOnSale => throw new NotImplementedException();

    }  
}
