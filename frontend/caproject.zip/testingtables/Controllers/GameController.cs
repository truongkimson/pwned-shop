﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using testingtables;
using testingtables.Models;
using testingtables.ViewModel;

namespace testingtables.Controllers
{
    public class GameController : Controller
    {
        private readonly Models.IGameRepository gameRepository;

        public GameController(Models.IGameRepository gameRepository)
        {
            this.gameRepository = gameRepository;
        }

        public IActionResult Index()
        {
            var gameListViewModel = new GameListViewModel();
            gameListViewModel.Games = gameRepository.getAllGame;
            return View(gameListViewModel);
        }
    }
}
