﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using testingtables.Models;

namespace testingtables.ViewModel
{
    public class GameListViewModel
    {
        public IEnumerable<Game> Games { get; set; }
    }
}
